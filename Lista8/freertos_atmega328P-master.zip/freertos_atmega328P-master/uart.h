#ifndef _UART_H
#define _UART_H

void uart_init(void);

FILE uart_file;

#endif
